// Import local images
import futevoleiImage from '@/assets/images/futevolei.jpg';

// Sport Images URLs
export const sportImages = {
  // Single image for all cases
  balls: [futevoleiImage],
  scenes: [futevoleiImage],
  courts: [futevoleiImage],
  
  // Hero background
  hero: futevoleiImage
};

// Categories checkout links
export const categoryLinks = {
  iniciante: "https://pay.kiwify.com.br/IXXcF4F",
  b: "https://pay.kiwify.com.br/739dkY2",
  c: "https://pay.kiwify.com.br/IoFpVpP",
  d: "https://pay.kiwify.com.br/A5CMKru"
};

export type CategoryType = 'iniciante' | 'b' | 'c' | 'd';

// Categories information
export const categories = [
  {
    id: 'iniciante',
    name: 'Iniciante',
    description: 'Para quem está começando no esporte e deseja ganhar experiência competitiva.',
    link: categoryLinks.iniciante
  },
  {
    id: 'b',
    name: 'Categoria B',
    description: 'Para atletas com experiência intermediária que já dominam as técnicas básicas.',
    link: categoryLinks.b
  },
  {
    id: 'c',
    name: 'Categoria C',
    description: 'Para atletas avançados com bom domínio técnico e experiência competitiva.',
    link: categoryLinks.c
  },
  {
    id: 'd',
    name: 'Categoria D',
    description: 'Para atletas de elite com alto nível técnico e grande experiência competitiva.',
    link: categoryLinks.d
  }
];
