import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { RiInstagramLine } from 'react-icons/ri';
import velhoLogo from '@/assets/images/velho.png';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-black bg-opacity-90 shadow-lg' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/">
          <div className="flex items-center">
            <img src={velhoLogo} alt="Circuito Velho Chico Logo" className="h-14 w-auto mr-2" />
            <h1 className="text-primary font-montserrat font-bold text-xl hidden md:block">
              1° Etapa Circuito Velho Chico (Aruba)
            </h1>
          </div>
        </Link>
        <a 
          href="https://www.instagram.com/futsaofrancisco?igsh=anM0YTNsOW1hMmJ1" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-white hover:text-primary transition duration-300"
          aria-label="Instagram"
        >
          <RiInstagramLine className="h-6 w-6" />
        </a>
      </div>
    </header>
  );
}
