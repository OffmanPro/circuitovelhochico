import { RiInstagramLine } from 'react-icons/ri';
import velhoLogo from '@/assets/images/velho.png';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-black py-10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-6 md:mb-0">
            <img src={velhoLogo} alt="Circuito Velho Chico Logo" className="h-12 w-auto mr-3" />
            <div>
              <h3 className="text-primary font-montserrat font-bold text-lg">Circuito Velho Chico</h3>
              <p className="text-gray-400 text-sm">Futevôlei São Francisco</p>
            </div>
          </div>
          
          <div className="flex flex-col items-center md:items-end">
            <div className="flex space-x-4 mb-3">
              <a 
                href="https://www.instagram.com/futsaofrancisco?igsh=anM0YTNsOW1hMmJ1" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-primary transition duration-300"
                aria-label="Instagram"
              >
                <RiInstagramLine className="h-6 w-6" />
              </a>
            </div>
            <p className="text-gray-400 text-sm">© {currentYear} Circuito Velho Chico. Todos os direitos reservados.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
