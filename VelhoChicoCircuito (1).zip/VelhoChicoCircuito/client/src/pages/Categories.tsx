import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { categories, CategoryType } from '@/assets/sportImages';
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';

export default function Categories() {
  const [_, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | null>(null);
  
  const handleBackClick = () => {
    setLocation('/');
    window.scrollTo(0, 0);
  };
  
  const handleCategorySelect = (categoryId: CategoryType) => {
    setSelectedCategory(categoryId);
  };
  
  return (
    <section className="py-24 md:py-32 bg-gradient-dark min-h-screen">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-montserrat font-bold mb-4 text-primary">Escolha sua Categoria</h2>
          <p className="text-xl max-w-3xl mx-auto mb-6">Selecione a categoria que melhor representa seu nível e garanta sua vaga neste evento incrível!</p>
          <div className="w-24 h-1 bg-primary mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {categories.map((category) => (
            <div 
              key={category.id}
              className={`category-card bg-black bg-opacity-60 rounded-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl ${
                selectedCategory === category.id ? 'ring-4 ring-primary' : ''
              }`}
              onClick={() => handleCategorySelect(category.id as CategoryType)}
            >
              <div className="h-24 bg-primary flex items-center justify-center">
                <h3 className="text-2xl font-montserrat font-bold text-black">{category.name}</h3>
              </div>
              <div className="p-6">
                <p className="mb-6 text-gray-300">{category.description}</p>
                <a 
                  href={category.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block w-full bg-primary hover:bg-yellow-500 text-black font-montserrat font-bold text-center py-3 rounded-md transition-all duration-300"
                >
                  Quero garantir minha vaga
                </a>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button
            onClick={handleBackClick}
            variant="ghost"
            className="text-primary hover:text-yellow-500 font-montserrat font-semibold flex items-center mx-auto transition-all duration-300"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Voltar para informações do evento
          </Button>
        </div>
      </div>
    </section>
  );
}
