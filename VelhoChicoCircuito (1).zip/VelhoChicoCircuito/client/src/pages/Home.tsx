import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { sportImages } from '@/assets/sportImages';
import velhoLogo from '@/assets/images/velho.png';
import { 
  Award, 
  Users, 
  Gift,
  ChevronRight
} from 'lucide-react';

export default function Home() {
  const [_, setLocation] = useLocation();

  const handleInterestClick = () => {
    setLocation('/categorias');
    window.scrollTo(0, 0);
  };
  
  return (
    <div className="pt-20 md:pt-24">
      {/* Hero Section */}
      <div className="relative clip-path-bottom bg-dark overflow-hidden" style={{minHeight: "100vh"}}>
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-black to-transparent opacity-80 z-10"></div>
          <div className="absolute inset-0 bg-black opacity-40 z-10"></div>
          <img 
            src={sportImages.hero} 
            alt="Quadra de areia para futevôlei" 
            className="absolute inset-0 w-full h-full object-cover z-0"
          />
        </div>
        
        <div className="container mx-auto px-4 relative z-10 pt-24 pb-40">
          <div className="flex flex-col items-center text-center mb-10">
            <div className="w-64 h-64 mb-6 animate-pulse">
              <img src={velhoLogo} alt="Circuito Velho Chico Logo" className="w-full h-full object-contain" />
            </div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-montserrat font-extrabold text-primary mb-4 tracking-tight">
              1° Etapa Circuito Velho Chico
            </h2>
            <p className="text-2xl md:text-3xl font-montserrat font-semibold mb-2">Aruba</p>
            <div className="w-24 h-1 bg-primary mb-8"></div>
          </div>
          
          <div className="max-w-3xl mx-auto text-center mb-12">
            <p className="text-lg md:text-xl mb-6 leading-relaxed">
              Prepare-se para a adrenalina pura da 1ª Etapa do Circuito Velho Chico de Futevôlei! Uma experiência única que vai reunir os melhores atletas e entusiastas do esporte em um cenário incrível.
            </p>
            <p className="text-lg md:text-xl mb-8 leading-relaxed">
              Venha mostrar sua habilidade nas quadras de areia, conectar-se com outros apaixonados pelo futevôlei e competir em um ambiente de alto nível. Não importa sua categoria, o Circuito Velho Chico é sua chance de brilhar!
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
              <div className="bg-black bg-opacity-60 p-6 rounded-lg border-l-4 border-primary">
                <h3 className="text-primary font-montserrat font-bold text-xl mb-2">Localização Especial</h3>
                <p>As melhores quadras de areia selecionadas para uma competição em cenário espetacular.</p>
              </div>
              <div className="bg-black bg-opacity-60 p-6 rounded-lg border-l-4 border-primary">
                <h3 className="text-primary font-montserrat font-bold text-xl mb-2">Para Todos os Níveis</h3>
                <p>Categorias Iniciante, B, C e D para garantir disputas justas e emocionantes.</p>
              </div>
            </div>
            
            <Button
              onClick={handleInterestClick}
              className="bg-primary hover:bg-yellow-500 text-black font-montserrat font-bold text-xl px-12 py-8 rounded-full transform transition-all duration-300 hover:scale-105 shadow-lg"
            >
              TENHO INTERESSE
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-dark">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-montserrat font-bold mb-4 text-primary">Por que participar do Circuito Velho Chico?</h2>
            <div className="w-24 h-1 bg-primary mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-black bg-opacity-50 rounded-lg p-6 border-b-4 border-primary transform transition-all duration-300 hover:-translate-y-2">
              <div className="text-primary text-4xl mb-4">
                <Award className="h-12 w-12" />
              </div>
              <h3 className="text-xl font-montserrat font-bold mb-2">Experiência Premium</h3>
              <p className="text-gray-300">Organização profissional, infraestrutura de qualidade e ambiente perfeito para mostrar seu talento.</p>
            </div>
            
            {/* Feature 2 */}
            <div className="bg-black bg-opacity-50 rounded-lg p-6 border-b-4 border-primary transform transition-all duration-300 hover:-translate-y-2">
              <div className="text-primary text-4xl mb-4">
                <Users className="h-12 w-12" />
              </div>
              <h3 className="text-xl font-montserrat font-bold mb-2">Networking Esportivo</h3>
              <p className="text-gray-300">Conecte-se com atletas de diferentes regiões, torcedores e patrocinadores do futevôlei.</p>
            </div>
            
            {/* Feature 3 */}
            <div className="bg-black bg-opacity-50 rounded-lg p-6 border-b-4 border-primary transform transition-all duration-300 hover:-translate-y-2">
              <div className="text-primary text-4xl mb-4">
                <Gift className="h-12 w-12" />
              </div>
              <h3 className="text-xl font-montserrat font-bold mb-2">Premiações Exclusivas</h3>
              <p className="text-gray-300">Competição com premiações especiais para todas as categorias e reconhecimento aos melhores atletas.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="py-16 bg-gradient-dark">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-montserrat font-bold mb-4 text-primary">O Melhor do Futevôlei</h2>
            <div className="w-24 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-lg max-w-3xl mx-auto">Confira alguns momentos do esporte que você vai vivenciar no Circuito Velho Chico</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Image 1 */}
            <div className="relative overflow-hidden rounded-lg group h-64">
              <img 
                src={sportImages.scenes[0]} 
                alt="Futevôlei na quadra de areia" 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 group-hover:bg-opacity-20 transition-all duration-300"></div>
            </div>
            
            {/* Image 2 */}
            <div className="relative overflow-hidden rounded-lg group h-64">
              <img 
                src={sportImages.balls[0]} 
                alt="Bola de futevôlei" 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 group-hover:bg-opacity-20 transition-all duration-300"></div>
            </div>
            
            {/* Image 3 */}
            <div className="relative overflow-hidden rounded-lg group h-64">
              <img 
                src={sportImages.courts[0]} 
                alt="Quadra de areia" 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 group-hover:bg-opacity-20 transition-all duration-300"></div>
            </div>
            
            {/* Image 4 */}
            <div className="relative overflow-hidden rounded-lg group h-64">
              <img 
                src={sportImages.scenes[1]} 
                alt="Quadra de areia para futevôlei" 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 group-hover:bg-opacity-20 transition-all duration-300"></div>
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <Button
              onClick={handleInterestClick}
              className="flex items-center gap-2 bg-primary hover:bg-yellow-500 text-black font-montserrat font-bold px-6 py-3 rounded-md transform transition-all duration-300 hover:scale-105"
            >
              Quero Participar <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
